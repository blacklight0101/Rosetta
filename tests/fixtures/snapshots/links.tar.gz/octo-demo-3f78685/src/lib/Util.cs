namespace Demo.Lib { public static class Util { } }
