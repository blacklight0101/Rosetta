namespace Demo { public class App { } }
